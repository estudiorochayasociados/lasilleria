<footer class="ps-footer site-footer"> 
    <div class="ps-footer__copyright">
        <div class="ps-container">
            <div class="row">
                <div class=" col-sm-12 col-xs-12 text-right ">
                    <p>&copy; Copyright by <span>La Sillería</span>. <a href="http://www.estudiorochayasoc.com.ar" target="_blank">Estudio Rocha & Asociados</a>.</p>
                </div> 
            </div>
        </div>
    </div>
</footer>

<div class="ps-loading">
    <div class="loader ">
        <div class="loader__item"></div>
        <div class="loader__item"></div>
        <div class="loader__item"></div>
        <div class="loader__item"></div>
        <div class="loader__item"></div>
    </div>
</div>

<div style="position: fixed;bottom:20px;left:15px;z-index: 999">
    <a target="_blank" href="https://m.me/1016178075208643" style="vertical-align:middle;box-shadow:0px 0px 10px #333;font-size:14px;padding:10px;border-radius:5px;background-color:#1787fb;color:white;text-shadow:none;">
        <i class="fa fa-lg fa-facebook-square"></i> <span class="hidden-xs hidden-sm">Comunicate vía</span> Facebook
    </a> &nbsp;
    <a target="_blank" href="https://wa.me/543564586460" style="vertical-align:middle;box-shadow:0px 0px 10px #333;font-size:14px;padding:10px;border-radius:5px;background-color:#369317;color:white;text-shadow:none;">
        <i class="fa fa-lg fa-whatsapp"></i> <span class="hidden-xs hidden-sm">Comunicate vía</span> WhatsApp
    </a>
</div>

<script src="<?= URL ?>/assets/plugins/jquery.min.js"></script>
<script src="<?= URL ?>/assets/plugins/lightGallery-master/dist/js/lightgallery-all.min.js"></script>
<script src="<?= URL ?>/assets/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?= URL ?>/assets/plugins/owl-carousel/owl.carousel.min.js"></script>
<script src="<?= URL ?>/assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="<?= URL ?>/assets/plugins/jquery-bar-rating/dist/jquery.barrating.min.js"></script>
<script src="<?= URL ?>/assets/plugins/imagesloaded.pkgd.js"></script>
<script src="<?= URL ?>/assets/plugins/masonry.pkgd.min.js"></script>
<script src="<?= URL ?>/assets/plugins/isotope.pkgd.min.js"></script>
<script src="<?= URL ?>/assets/plugins/slick/slick/slick.min.js"></script>
<script src="<?= URL ?>/assets/plugins/jquery.matchHeight-min.js"></script>
<script src="<?= URL ?>/assets/plugins/elevatezoom/jquery.elevatezoom.js"></script>
<script src="<?= URL ?>/assets/plugins/gmap3.min.js"></script>
<script src="<?= URL ?>/assets/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Custom scripts-->
<script src="<?= URL ?>/assets/js/main.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDsUcTjt43mTheN9ruCsQVgBE-wgN6_AfY&amp;region=GB"></script>
 
