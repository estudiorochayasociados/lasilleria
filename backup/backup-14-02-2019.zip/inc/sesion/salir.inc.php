<?php
session_destroy();
$funciones->headerMove(URL . '/index');
?>